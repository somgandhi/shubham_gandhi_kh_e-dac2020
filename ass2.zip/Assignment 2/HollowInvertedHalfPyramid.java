package edac;
import java.util.Scanner;
class HollowInvertedHalfPyramid
{
    public static void main (String args[])
    {
        Scanner sc =new Scanner (System.in);
        System.out.print ("Enter number of rows: ");
        int row = sc.nextInt();
        for (int i=1; i<=row;i++)
        {
            for (int j=i; j<=row; j++)
            {
                if (i==1 || j==i || j==row)
                {
                System.out.print ("* ");
                }
                else
                {
                System.out.print ("  ");
                }
            }
        System.out.println();
        }
    }
}