package edac;
class Pattern1
{
    public static void main (String args[])
    {
    int m = 8;
    for (int i=1;i<=9;i++)
    {
        for(int j=1;j<=m;j++)
        {
        System.out.print(" ");
        }
        m--;
            for (int k=1;k<=i;k++)
            {
                System.out.print(i +" ");
            }
            System.out.println();
    }
    }
}

        
