package edac;
class Pattern2
{
    public static void main (String args[])
    {
        int m=8;
        for (int i=1;i<=9;i++)
            {
                int value=1;
                for(int j=1;j<=m;j++)
                {
                System.out.print (" ");
                }
                m--;
                for (int k=1;k<=i;k++)
                {
                System.out.print(value +" ");
                value++;
                }
                System.out.println();
            }
    }
}