class Q5
{
	static void count(String str)
	{
		char ch[]=str.toCharArray();
		for (int i=0;i<ch.length;i++)
		{
			String s = "";
			while(i<ch.length && ch[i] != ' ')
			{
				s = s + ch[i];
				i++;
			}
			System.out.print(s.length() +" ");
		}
	}
	public static void main(String args[])
	{
		String str = "I am a Java Programmer";
		count(str);
	}
}