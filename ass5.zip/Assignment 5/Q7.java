import java.util.*;
class Q7
{
	static void convertCase(StringBuffer str)
	{
		int len = str.length();
		for (int i=0; i<len; i++)
		{
			Character c = str.charAt(i);
			if(Character.isLowerCase(c))
				str.replace(i, i+1, Character.toUpperCase(c) +"");
			else
				str.replace(i, i+1, Character.toLowerCase(c) +"");
		}
	}
	public static void main(String args[])
	{
		StringBuffer str = new StringBuffer("Hello World");
		convertCase(str);
		System.out.println(str);
	}
}