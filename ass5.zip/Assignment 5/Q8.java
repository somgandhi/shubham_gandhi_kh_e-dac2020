import java.util.*;
class Q8
{
	public static void main(String args[])
	{
		System.out.print("Enter String to be reversed : ");
		Scanner sc = new Scanner(System.in);
		String str=sc.nextLine();
		
		StringBuffer sb = new StringBuffer(str);		//Using StringBuffer inbuilt "reverse()" method
		System.out.println(sb.reverse());
		
		StringBuilder sbuilder = new StringBuilder(str);	//Using StringBuilder inbuilt "reverse()" method
		System.out.println(sbuilder.reverse());
		
		char ch[]=str.toCharArray();				//Using "toCharArray()" method of String
		for(int i=ch.length-1; i>=0; i--)
		{
			System.out.print(ch[i]);
		}
		System.out.println();
		
		for (int i=str.length()-1; i>=0; i--)			//By Using "charAt()" function of String
		{
			System.out.print(str.charAt(i));
		}
	}
}