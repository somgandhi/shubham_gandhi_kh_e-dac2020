import java.util.*;
class Q6{
		static void thirdLargest(int a[], int n)
		{
			int first = a[0];
			int second = Integer.MIN_VALUE;
			int third = Integer.MIN_VALUE;
			for (int i=0; i<n; i++)
			{
			if (a[i]>first)
			{
				third=second;
				second=first;
				first=a[i];
			}
			else if (a[i]>second)
			{
				third=second;
				second=a[i];
			}
			else if (a[i]>third)
				third=a[i];
			}
			System.out.print("Third largest element : "+third);
			
		}
	public static void main (String args[])
	{
		Scanner s = new Scanner(System.in);
		System.out.print("Enter the size of array : ");
		int n = s.nextInt();
		int a[] = new int [n];
		for (int i=0; i<n; i++)
		{
			a[i]=s.nextInt();
		}
		thirdLargest(a,n);
	}
}