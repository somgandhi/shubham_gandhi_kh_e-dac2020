import java.util.Scanner;

public class Q4 {

    private static Scanner scanner = new Scanner(System.in);

    private static int[] inputArray(int i) {
        System.out.print("Enter Length of Array " + i + " : ");
        int[] ret = new int[scanner.nextInt()];
        System.out.print("===Enter Elements of Array " + i + "===\n");
        for (int j = 0; j < ret.length; j++) {
            System.out.print("array" + i + "[" + j + "] : ");
            ret[j] = scanner.nextInt();
        }
        return ret;
    }

    public static void main(String[] args) {
        int[] a = inputArray(1);
        boolean isAscending = true, isDescending = true;
        for (int i = 0; i < a.length - 1; i++) {
            isAscending = isAscending && a[i] <= a[i + 1];
            isDescending = isDescending && a[i] >= a[i + 1];
        }
        System.out.println(isAscending ? "ASCENDING" : (isDescending ? "DESCENDING" : (!isAscending && !isDescending ? "RANDOM" : "")));
    }
}