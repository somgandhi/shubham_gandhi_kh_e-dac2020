import java.util.Arrays;
import java.util.Scanner;

public class Q2 {

    private static Scanner scanner = new Scanner(System.in);

    private static int[] inputArray(int i) {
        System.out.print("Enter Length of Array " + i + " : ");
        int[] ret = new int[scanner.nextInt()];
        System.out.print("===Enter Elements of Array " + i + "===\n");
        for (int j = 0; j < ret.length; j++) {
            System.out.print("array" + i + "[" + j + "] : ");
            ret[j] = scanner.nextInt();
        }
        return ret;
    }

    public static void main(String[] args) {
        int[] a = inputArray(1);
        int[] b = new int[(int) (a.length / 3)];
        for (int i = 0, j = 0; i < b.length; i++)
            b[j] = ((a[i] + a[i + 1] + a[i + 2]) / 3);
        System.out.println(Arrays.toString(b));
    }

}