import java.util.*;
class Q3
{
	public static void main(String args[])
	{
		int n=0;
		for (int i=1; i<=6; i++)
		{
			if (i%2==0)
			{
			n = (int)(Math.pow(i,2));
			System.out.print(n +" ");
			}
			else
			{
			n = (int)(Math.pow(i,3));
			System.out.print(n +" ");
			}
		
		}
	}
}