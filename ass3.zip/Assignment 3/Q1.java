import java.util.Arrays;
import java.util.Scanner;

public class Q1 {

    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        int[] a = inputArray(1);
        int[] b = inputArray(2);
        int[] c = new int[a.length + b.length];
        for (int aNext = 0, bNext = 0, cNext = 0; cNext < c.length; aNext++, bNext++, cNext++)
            if (aNext < a.length && bNext < b.length) {
                c[cNext] = a[aNext];
                c[++cNext] = b[bNext];
            } else if (aNext < a.length)
                c[cNext] = a[aNext];
            else if (bNext < b.length)
                c[cNext] = b[bNext];
        System.out.println(Arrays.toString(c));
    }

    private static int[] inputArray(int i) {
        System.out.print("Enter Length of Array " + i + " : ");
        int[] ret = new int[scanner.nextInt()];
        System.out.print("===Enter Elements of Array " + i + "===\n");
        for (int j = 0; j < ret.length; j++) {
            System.out.print("array" + i + "[" + j + "] : ");
            ret[j] = scanner.nextInt();
        }
        return ret;
    }

}