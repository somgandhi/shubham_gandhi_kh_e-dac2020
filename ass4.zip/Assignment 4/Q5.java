import java.util.*;
class SimpleInterest
{
	int principalAmount;
	static int rateOfInterest;
	int time;
	int Si;
	
	void calculateInterest()
	{
		Si=principalAmount*rateOfInterest*time;
	}
	void getData(int principalAmount, int rateOfInterest, int time)
	{
		this.principalAmount=principalAmount;
		this.rateOfInterest=rateOfInterest;
		this.time=time;
	}
	void display()
	{
		System.out.println("SimpleInterest = " +Si);
	}
	public static void main(String args[])
	{
		SimpleInterest s=new SimpleInterest();
		Scanner sc=new Scanner(System.in);
		int p=sc.nextInt();
		int r=sc.nextInt();
		int t=sc.nextInt();
		s.getData(p,r,t);
		s.calculateInterest();
		s.display();
	}
}