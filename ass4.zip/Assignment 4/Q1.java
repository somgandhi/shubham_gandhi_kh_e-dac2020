class Student
{
	int rollNo;
	String name;
	int marks;
		
	void getData(int rollNo, String name, int marks)
	{
		this.rollNo=rollNo;
		this.name=name;
		this.marks=marks;
	}
	void printData()
	{
		System.out.println("Roll No. = " +rollNo);
		System.out.println("Name = " +name);
		System.out.println("Marks = " +marks);
	}
}
class Q1
{
	public static void main(String args[])
	{
	Student std = new Student();
	std.getData(032,"Himanshu",600);
	std.printData();
	Student stud = new Student();
	stud.getData(031,"Sumit",800);
	stud.printData();
	}
}